import threading
import time
def str(num):
    for i in range(num):
        print('3244444444444444444444444444444444444444444444444444444444243')
        time.sleep(1)
def colors(num):
    for i in range(num):
        print('4389508409827584555555555555555555555555555555555555555555555')
        time.sleep(1)

t1 = threading.Thread(target=str,args=(5,))
t2 = threading.Thread(target=colors,args=(5,))
t1.start()
t2.start()

